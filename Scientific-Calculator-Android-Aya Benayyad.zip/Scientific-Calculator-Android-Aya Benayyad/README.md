# Scientific-Calculator-Android-App

An andoid application which performs the scientific calculator's functionalities. It is built on android studio so you can run this project by installing apk file on any android mobile phone of API level between 22 and 29. You can also work on this project using android studios.
- - - -

## Screenshots:

* Main Page - 

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;    ![1](https://user-images.githubusercontent.com/37416018/67119647-61be4e00-f209-11e9-81c6-c7ca0cbc0eab.PNG)
- - - -


* Factorial of 5 - 

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;    ![2](https://user-images.githubusercontent.com/37416018/67120072-591a4780-f20a-11e9-88f8-b0655f38273b.PNG)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;    ![3](https://user-images.githubusercontent.com/37416018/67120091-61728280-f20a-11e9-957a-499d8f944824.PNG)
- - - -
<br>

* Value of sin 90 degree - 

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;    ![4](https://user-images.githubusercontent.com/37416018/67120552-5704b880-f20b-11e9-992a-5e9c9086f7ec.PNG)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;    ![5](https://user-images.githubusercontent.com/37416018/67120557-59ffa900-f20b-11e9-96f7-4faf364e90cc.PNG)
- - - -
<br>

* Exponential - 

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;    ![6](https://user-images.githubusercontent.com/37416018/67120564-5e2bc680-f20b-11e9-92bb-7aacac657966.PNG)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;    ![7](https://user-images.githubusercontent.com/37416018/67120566-5f5cf380-f20b-11e9-882c-6cb283489451.PNG)
- - - -
<br>

* PI - 

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;    ![8](https://user-images.githubusercontent.com/37416018/67120569-61bf4d80-f20b-11e9-9701-aabd153ecfaa.PNG)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;    ![9](https://user-images.githubusercontent.com/37416018/67120582-66840180-f20b-11e9-8e02-088647a8b540.PNG)

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;    ![10](https://user-images.githubusercontent.com/37416018/67120589-68e65b80-f20b-11e9-8355-af9c3db1474f.PNG)
- - - -

* Built With - 
    * Android Studio
    * Java
- - - -

* License -
    * This project is licensed under the Eclipse Public License.
